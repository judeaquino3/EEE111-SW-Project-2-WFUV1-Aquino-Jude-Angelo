class RegDbEntry:
    def __init__(self,
                 idbarangay=1,
                 name='Employee Name',
                 barangay='Male',
                 age='Training',
                 gender='Remote'):
        self.idbarangay = idbarangay
        self.name = name
        self.barangay = barangay
        self.age = age
        self.gender = gender
